﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

namespace TicTacToe
{
    public partial class MainWindow : Window
    {
        private string currentPlayer = "X";
        private string[] board = new string[9];
        private List<string> moves = new List<string>();
        private string selectedMode = "Против человека";
        private string statsFile = "stats.json";
        private Random random = new Random();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            ResetGame();
            GameStatusText.Text = "";
            GameGrid.Visibility = Visibility.Visible;
        }


        private void StatisticsButton_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists(statsFile))
            {
                string json = File.ReadAllText(statsFile);
                var stats = JsonSerializer.Deserialize<Dictionary<string, int>>(json);
                MessageBox.Show($"Победы X: {stats["X"]}\nПобеды O: {stats["O"]}\nНичьи: {stats["Draw"]}", "Статистика");
            }
            else
            {
                MessageBox.Show("Статистика пока отсутствует.", "Статистика");
            }
        }

        private void ModeButton_Click(object sender, RoutedEventArgs e)
        {
            var modes = new[] { "Против человека", "Бот Легкий"};

            // Создаем новое окно для выбора режима
            var modeWindow = new Window
            {
                Title = "Выберите режим",
                Height = 200,
                Width = 300
            };

            // Создаем ListBox для выбора
            var listBox = new ListBox
            {
                ItemsSource = modes,
                Margin = new Thickness(10),
                VerticalAlignment = VerticalAlignment.Center
            };

            // Добавляем обработчик события для изменения выбора
            listBox.SelectionChanged += (s, args) =>
            {
                selectedMode = listBox.SelectedItem.ToString();
                SelectedModeText.Text = selectedMode;
                modeWindow.Close(); // Закрываем окно после выбора
            };

            // Устанавливаем ListBox в качестве содержимого окна
            modeWindow.Content = listBox;

            // Показываем окно и проверяем, что режим был выбран
            modeWindow.ShowDialog();
        }


        private void GameButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            int index = int.Parse(button.Name.Replace("Button", ""));

            if (string.IsNullOrEmpty(button.Content?.ToString()) && board[index] == null)
            {
                board[index] = currentPlayer;
                button.Content = currentPlayer;
                moves.Add($"Ход {currentPlayer} в клетку {index}");
                MoveList.ItemsSource = null;
                MoveList.ItemsSource = moves;

                if (CheckWinner())
                {
                    GameOver($"{currentPlayer} победил!");
                    return;
                }

                if (Array.IndexOf(board, null) == -1)
                {
                    GameOver("Ничья!");
                    return;
                }

                currentPlayer = currentPlayer == "X" ? "O" : "X";

                if (selectedMode != "Против человека" && currentPlayer == "O")
                    BotMove();
            }
        }

        private void BotMove()
        {
            int move = -1;

            if (selectedMode == "Бот Легкий")
            {
                var emptyCells = new List<int>();
                for (int i = 0; i < board.Length; i++)
                    if (board[i] == null)
                        emptyCells.Add(i);

                move = emptyCells[random.Next(emptyCells.Count)];
            }

            if (move >= 0)
            {
                board[move] = "O";
                var button = GameGrid.Children[move] as Button;
                button.Content = "O";
                moves.Add($"Ход O в клетку {move}");
                MoveList.ItemsSource = null;
                MoveList.ItemsSource = moves;

                if (CheckWinner())
                {
                    GameOver("O победил!");
                    return;
                }

                currentPlayer = "X";
            }
        }

        private bool CheckWinner()
        {
            int[][] winPatterns = {
                new[] { 0, 1, 2 }, new[] { 3, 4, 5 }, new[] { 6, 7, 8 },
                new[] { 0, 3, 6 }, new[] { 1, 4, 7 }, new[] { 2, 5, 8 },
                new[] { 0, 4, 8 }, new[] { 2, 4, 6 }
            };

            foreach (var pattern in winPatterns)
            {
                if (board[pattern[0]] != null &&
                    board[pattern[0]] == board[pattern[1]] &&
                    board[pattern[1]] == board[pattern[2]])
                    return true;
            }

            return false;
        }

        private void GameOver(string result)
        {
            GameStatusText.Text = result;
            GameGrid.Visibility = Visibility.Collapsed;
            UpdateStatistics(currentPlayer == "X" ? "X" : "O");
        }

        private void ResetGame()
        {
            for (int i = 0; i < board.Length; i++)
            {
                board[i] = null;
                (GameGrid.Children[i] as Button).Content = "";
            }

            moves.Clear();
            MoveList.ItemsSource = null;
            currentPlayer = "X";
        }

        private void UpdateStatistics(string winner)
        {
            var stats = new Dictionary<string, int> { { "X", 0 }, { "O", 0 }, { "Draw", 0 } };
            if (File.Exists(statsFile))
                stats = JsonSerializer.Deserialize<Dictionary<string, int>>(File.ReadAllText(statsFile));

            if (winner == "X" || winner == "O")
                stats[winner]++;
            else
                stats["Draw"]++;

            File.WriteAllText(statsFile, JsonSerializer.Serialize(stats));
        }
    }
}
